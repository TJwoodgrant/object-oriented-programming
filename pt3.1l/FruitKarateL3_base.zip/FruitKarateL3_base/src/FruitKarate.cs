﻿using System;
using System.Collections.Generic;
using SwinGameSDK;

namespace MyGame
{
	public class FruitKarate
	{
        private List<Fruit> _fruit = new List<Fruit> ();

		private void LoadResources ()
		{
			SwinGame.LoadBitmapNamed ("Cherry", "Cherry.png");
			SwinGame.LoadBitmapNamed ("Gooseberry", "Gooseberry.png");
			SwinGame.LoadBitmapNamed ("Blueberry", "Blueberry.png");
			SwinGame.LoadBitmapNamed ("Pomegranate", "Pomegranate.png");
			SwinGame.LoadBitmapNamed ("Apricot", "Apricot.png");
			SwinGame.LoadBitmapNamed ("Raspberry", "Raspberry.png");
			SwinGame.LoadBitmapNamed ("Blackberry", "Blackberry.png");
			SwinGame.LoadBitmapNamed ("Strawberry", "Strawberry.png");
			SwinGame.LoadBitmapNamed ("Currant", "Currant.png");

			SwinGame.LoadSoundEffectNamed ("Splat", "Splat-SoundBible.com-1826190667.wav");
		}

		public FruitKarate ()
		{
			LoadResources ();
		}

        public void LaunchFruit()
        {
            Fruit f = new Fruit ();
            _fruit.Add (f);

        }

        public void Update()
        {
            foreach(Fruit f in _fruit)
            {
                f.Update ();
            }
        }

        public void Draw()
        {
            foreach (Fruit f in _fruit) {
                f.Draw ();
            }
        }
		
	}
}

