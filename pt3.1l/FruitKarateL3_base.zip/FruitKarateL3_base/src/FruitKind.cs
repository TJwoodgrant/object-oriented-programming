﻿using System;

namespace MyGame
{
	public enum FruitKind
	{
		Cherry,
		Gooseberry,
		Blueberry,
		Pomegranate,
		Apricot,
		Raspberry,
		Blackberry,
		Strawberry,
		Currant
	}
}

